import { CustomData } from 'lightweight-charts';

/**
 * DualRangeHistogram Series Data
 */
export interface DualRangeHistogramData extends CustomData {
	values: number[];
}
