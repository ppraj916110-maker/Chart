import { CustomData } from 'lightweight-charts';

/**
 * GroupedBars Series Data
 */
export interface GroupedBarsData extends CustomData {
	values: number[];
}
