import { CustomData } from 'lightweight-charts';

/**
 * StackedBars Series Data
 */
export interface StackedBarsData extends CustomData {
	values: number[];
}
