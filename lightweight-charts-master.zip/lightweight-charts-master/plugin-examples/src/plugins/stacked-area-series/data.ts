import { CustomData } from 'lightweight-charts';

/**
 * StackedArea Series Data
 */
export interface StackedAreaData extends CustomData {
	values: number[];
}
